var express     = require("express"),
    app         = express(),
    bodyParser  = require("body-parser"),
    mongoose    = require("mongoose");



// connect mongoose
mongoose.connect("mongodb://localhost/yelp_camp");
//use bodyParser
app.use(bodyParser.urlencoded({extended: true}));
//setup ejs file handling-
app.set("view engine", "ejs");


//SCHEMA Setup
var campgroundSchema = new mongoose.Schema({
    name: String,
    image: String,
    description: String
});

//compile into mognoose model
var Campground = mongoose.model("Campground", campgroundSchema);


// add homepage route
app.get("/", function(req, res){
    res.render("landing");
});


// add INDEX route- display campgrounds
app.get("/campgrounds", function(req, res){
        Campground.find({}, function(err, allCampgrounds){                      //get all campgrounds from DB file
           if(err){
               console.log(err)
           } else {
                res.render("index.ejs", {campgrounds: allCampgrounds});       //render to webpage   
           }
    });                                                          
});


// add NEW route - display form for adding new campground to DB
app.get("/campgrounds/new", function(req, res) {
    res.render("new.ejs");
});


// add in CREATE route - add new campfround to DB
app.post("/campgrounds", function(req, res){
        console.log("you hit the post route");                                  //console check
        var name = req.body.name;                                               //get data from from and add to array
        var image = req.body.image;                                             //redirect back to campgrounds page
        var desc = req.body.description;                                 
        var newCampground = {name: name, image: image, description: desc};      //new campground object placeholder var
        Campground.create(newCampground, function(err, newlyCreated){           //create new campgrounda dn save to DB
            if(err){
                console.log(err);
            } else {
                 res.redirect("/campgrounds");                                  // redirect abck to /campgrounds page after data added  to show new data
            }
        });                                       
});


//Create SHOW route - shows info about one selected campground
app.get("/campgrounds/:id", function(req, res) {
    Campground.findById(req.params.id, function(err, foundCampground){
        if(err){
            console.log(err);
        } else {
            res.render("show", {campground: foundCampground});                                                                            
            
        }
    });
});


//Listen for ports and IPs
app.listen(process.env.PORT, process.env.IP, function(){
    console.log("YelpCamp is running");
});











//==============================================================================
// add new campground (hardcoded) to db
// Campground.create(
//      { 
//         name: "Coopers Bluff",
//         image:"https://pixabay.com/get/e03db50f2bfc1c22d2524518b7444795ea76e5d004b0144296f0c67bafe8b1_340.jpg",
//         description: "This is a great campground! Lots of birds and we even saw a bear"
//      }, function(err, campground) {
//          if(err){
//             console.log(err);
//      } else {
//          console.log("new cmapground added: ");
//          console.log(campground);
//      }
// });


// global campgrounds array
//  var campgrounds = [
       
//         { name: "Misty Thicket", image:"https://farm8.staticflickr.com/7399/9211397472_e6d0a7c6fd.jpg"},
//         { name: "Deep Hole", image:"https://pixabay.com/get/e83db40e28fd033ed1584d05fb1d4e97e07ee3d21cac104496f3c079aeedbdb0_340.jpg"}
//         // { name: "Coopers Bluff", image:""}
//         // { name: "Coopers Bluff", image:""}
//         // { name: "Coopers Bluff", image:""}
//         // { name: "Coopers Bluff", image:""}
//         // { name: "Coopers Bluff", image:""}
//         // { name: "Coopers Bluff", image:""}
//         ];
        
//==============================================================================

